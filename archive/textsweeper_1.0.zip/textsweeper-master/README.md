# textsweeper
"check" runs perl to find and replace 4 whitespaces with a tab.
Run "Makefile" to compile (linux version available only for now).
