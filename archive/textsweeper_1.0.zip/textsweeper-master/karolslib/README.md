# karolslib
My universal library. (Works only on Linux for now!)

Compile with make.

"check" runs perl to find and replace 4 whitespaces with a tab.

When linking against it add "-L/usr/lib/X11R6/lib -lX11".
